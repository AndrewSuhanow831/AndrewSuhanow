#include <stdio.h>
#include <stdlib.h.>
#include <time.h>
#include <conio.h>
#include <math.h>
#include <utility>
#include <malloc.h>
#define N 4
#define NMAX 10
	
typedef struct tnode //�������� ��������� ������
{
		char tfield;
		char ufield;
		struct tnode *left;
		struct tnode *right;
} btree ;	

struct tnode *talloc(void) // ��������� ������ ��� ��������� ������
{
	return (btree*) malloc(sizeof(btree*));
}

typedef struct st { //�������� ��������� �����
  char elem[NMAX]; // ������ �� �������� ��������� �����
  int top; // ������ �������
}stack;

stack *salloc(void) // ��������� ������ ��� ��������� ����� 
{
	return (stack*) malloc(sizeof(stack*));
}

void init(stack *stk) 
{
  stk->top = 0;
}

void push (stack *stk, char f) // ��������� ������ � ����
{
  if(stk->top < NMAX) 
  {
    stk->elem[stk->top] = f;
    stk->top++;
	}
}

char pop(stack *stk) 
{
  char el;
  if((stk->top) > 0)
  {
    stk->top--;
    el = stk->elem[stk->top];
    return el;
  }
  else
  {
    printf("Stack underflow!\n");
    return 0;
  }
}

bool isempty(stack *stk) // ���� �� ����?
{
	bool bln = false;
  if(stk->top == 0)
  	bln = true; 
  return bln;
}

void stkPrint(stack *stk) { //������ �������� �����, ������� �� � ��������
	int i = stk->top; // i - ���������� ��������� � �����
  if(isempty(stk)) 
  return; // ���� ����
  do 
  {
    i--;
    printf("%c\n", stk->elem[i]);
  }
  while(i>0);
}

bool stkTop(stack *stk, char key)  //�������� �� ������� � �������� ������� key � �����
{
	bool bln = false;
  	if((stk->top) > 0 && (stk->elem[stk->top-1] == key)) 
 		bln = true;
 	return bln;
}

bool term (char t) //�������� ����������?
{
	bool bln = false;
	int tr = (int)(t);
	if ((tr > 47) && (tr < 58))
	bln = true;
	return bln;
}

btree *addtree (btree *root, btree *tmp, char arr[NMAX], char key) // �������� ��������� ������
{
	btree *root2 = root, *root3;
	if (root == NULL)
	{
		root = talloc();
		root->tfield = '\0';
		root->ufield = '\0';
		root->right = NULL;
		root->left = NULL;
		if (term(key))
			root->tfield = key;
		else
			root->ufield = key;
	}
	else if (key == '=')
	{
	while (root2->left != NULL)
		root2 = root2->left;
	tmp = talloc();
	tmp->tfield = '\0';
	tmp->ufield = '\0';
	tmp->left = NULL;
	tmp->right = NULL;	
	root2->left = tmp;
	}
	else if (key == '|')
	{
//		stk = salloc();
//		stk->top = 0;
//		push(stk,key);
		arr[0] = key;
	}
	else if (arr[0] == '|')
//	if (stkTop(stk,key))
	{
		while (root2->left->ufield != '\0')
		{
			root2 = root2->left;
		}
		tmp = talloc();
		tmp->tfield = '\0';
		tmp->ufield = '\0';
		tmp->left = NULL;
		tmp->right = NULL;	
		root2->right = tmp;
		if (term(key))
		tmp->tfield = key;
		else
		tmp->ufield = key;	
		arr[0] = '\0';
	}
	else
	{
	while (root2->left != NULL)
		root2 = root2->left;
	if (term(key))
		root2->tfield = key;
	else
		root2->ufield = key;
	}
	return root;
}

void treeprint (btree *root) // ������ ������
{
	if (root != NULL)
	{
		treeprint(root->left);
		if (root->ufield != '\0')
		   printf("%c", root->ufield);
		if (root->tfield != '\0')
		   printf("%c", root->tfield);
		printf("\n");
		treeprint(root->right);
	}
}

stack *pop_term (stack *stk, btree *root)
{
	btree *root2 = root, *root3;
	while (root2 != NULL)
	{
		if (root2->tfield != '\0')
			push(stk, root2->tfield);
		root3 = root2->right;
		while (root3 != NULL)
		{
			if (root3->tfield != '\0')
				push(stk, root3->tfield);
			root3 = root3->right;
		}
		root2 = root2->left;
	}
	return stk;
}

stack *pop_unterm (stack *stk, btree *root)
{
	btree *root2 = root, *root3;
	while (root2 != NULL)
	{
		if (root2->ufield != '\0')
			push(stk, root2->ufield);
		root3 = root2->right;
		while (root3 != NULL)
		{
			if (root3->ufield != '\0')
				push(stk, root3->ufield);
			root3 = root3->right;
		}
		root2 = root2->left;
	}
	return stk;
}

void  counting (btree *root, int *dim_u, int *dim_t)
{
	int count_u = 0;
	int count_t = 0;
	btree *root2 = root, *root3;
	while (root2 != NULL)
	{
		if (root2->ufield != '\0')
			count_u++;
		if (root2->tfield != '\0')
			count_t++;
		root3 = root2->right;
		while (root3 != NULL)
		{
			if (root3->ufield != '\0')
				count_u++;
			if (root3->tfield != '\0')
				count_t++;
			root3 = root3->right;	
		}
		root2 = root2->left;
	}
	*dim_u = count_u;
	*dim_t = count_t;
}

void create_dArray (char **Arr, int row, int col)
{
	for(int i = 0; i <= row; i++) 
        for(int j = 0; j <= col; j++) 
            Arr[i][j] = '\0';
}
char ** dalloc(char **A, int  row, int col)
{
    A = (char **)malloc(row*sizeof(char *));
    for(int i = 0; i <= row; i++) {
        A[i] = (char *)malloc(col*sizeof(char));
    }
    return A;
}

void dfree(char **A, int row)
{
    for(int i = 0; i <= row; i++) {
        free(A[i]);
    }
    free(A);
}

void dprint(char **A,  int row,  int col)
{
    for(int i = 0; i <= row; i++) {
        for(int j = 0; j <= col; j++) {
            printf("%*c", 5, A[i][j]);
        }
        printf("\n");
    }
}

void create_table (btree *root, stack *stk, char **Arr, int row, int col)
{
	int i = row, j = 1;
	stk = pop_unterm (stk, root);
	while (!isempty(stk))
		Arr[i--][0] = pop(stk); 
	stk = pop_term (stk, root);		
	while (!isempty(stk))
		while (j < col)
			Arr[0][j++] = pop(stk); 
	Arr[0][j] = '$';	
}

stack *find_first (btree *root, stack *stk)
{
	if (root != NULL)
		{
			stk = find_first (root->left, stk);
			if ((root->ufield == '\0') && (not(stkTop(stk, root->tfield))))
				push (stk,root->tfield);
			stk = find_first (root->right, stk);
			if ((root->ufield == '\0') && (not(stkTop(stk, root->tfield))))
				push (stk,root->tfield);		
		}
	return stk;	
}

stack *FIRST (btree *root, stack *stk, char key)
{
	bool bln = false;
	btree *root2 = root, *root3;
	while (root2 != NULL)
	{
		if (root2->ufield == key)
			break;
		if (root2->tfield == key)	
			push(stk, root2->tfield);
		root3 = root2->right;
		while (root3 != NULL)
		{
			if (root3->ufield == key)
			{
				bln = true;
				break;
			}
			if (root3->tfield == key)
				push(stk, root3->tfield);
			root3 = root3->right;
		}
		if (bln)
			{
				root2 = root3;
				break;
			}
		root2 = root2->left;
	}
	stk = find_first (root2, stk);
}

void addTable (btree *root, stack *stk, char **Arr, int row, int col)
{
	char symbol;
	for (int i = 1; i <= row; i++)
	{
		stk = FIRST (root, stk, Arr[i][0]);
		while (!isempty(stk))
			{
				symbol = pop(stk);	
				for (int j = 1; j <= col; j++)
				{
					if (symbol == Arr[0][j])
					{
						Arr[i][j] = Arr[i][0];
						break;
					}
				}
			}	
	}
}

void output_file (FILE *F, char **Arr, int row, int col)
{
	for(int i = 0; i <= row; i++) 
        {
			for(int j = 0; j <= col; j++)
        	{
        		fprintf(F,"%2c",Arr[i][j]);
        	}
        fprintf(F,"\n");
		}
}

void find_index(char **Arr, int row, int col, char X, char a, int *u, int *t)
{
	for(int j = col; j > -1; j--) 
        for(int i = 0; i <= row; i++)
        {
			if (X == Arr[i][j])
				*u = i;
			if (a == Arr[i][j])
				*t = j;			
		}
}				 

stack *print_product (btree *root, stack *stk)
{
	bool bln = false;
//	btree *root2 = root, *root3;
	if (root != NULL)
		{
			stk = print_product (root->left, stk);
			if ((root->ufield != '\0') && (stk->elem[stk->top-2] != root->ufield))
				{
				push (stk,root->ufield);
				if ((root->tfield != '\0') && (stk->elem[stk->top-2] != root->tfield))
					push (stk,root->tfield);
				}
			stk = print_product (root->right, stk);
			if ((root->ufield != '\0') && (stk->elem[stk->top-2] != root->ufield))
				{
				push (stk,root->ufield);
				if ((root->tfield != '\0') && (stk->elem[stk->top-2] != root->tfield))
					push (stk,root->tfield);	
		 		}
		}
	return stk;	
}

void parser (btree *root, stack *stk, char **Arr, int row, int col, char *arr)
{
	char X, ip, a, i = 0;
	int u = 0, t = 0;
	push(stk,root->ufield);
	ip = arr[i];
	X = stk->elem[stk->top-1];
	printf("%c", arr[2]);
	while (X != '\0')
	{
		a = ip;
		find_index(Arr, row, col, X, a, &u, &t);
		if  (X == a)
			{
				stk->top--;
				ip = arr[++i];
			}
		else if (term(X))
			printf("ERROR");
		else if (Arr[u][t] == '\0')	
			printf("ERROR_1");			
		else if (not(term(Arr[u][t])))
		{
			stk->top--;
			printf("%c", Arr[u][t]);
			print_product (root,stk);
			stkPrint (stk);
		}
		X = stk->elem[stk->top-1];
	}
}

int main()
{
	int dim_u = 0, dim_t = 0, i = 0;
	char el, arr[NMAX], *str;
	arr[0] = '\0';
	btree *root = NULL;
	btree *tmp = NULL;
	stack *stk;
	FILE *F1;
	F1 = fopen("GRAMM.txt","r");
	while (!feof(F1))
	{
		fscanf(F1, "%c",&el);
		if (!feof(F1))
		   root = addtree (root, tmp, &arr[0], el);
	}	
	fclose(F1);
	treeprint(root);
	counting(root, &dim_u, &dim_t);
	stk = salloc();
	init(stk);
	char **Arr = dalloc(Arr, dim_u, dim_t + 1);
	create_dArray(Arr, dim_u, dim_t);
	create_table(root, stk, Arr, dim_u, dim_t + 1);
	addTable(root, stk, Arr, dim_u, dim_t);
	dprint(Arr, dim_u, dim_t + 1);
	F1 = fopen("LOG-file.txt","w");
	output_file(F1,Arr, dim_u, dim_t+1);
	fclose(F1);
	F1 = fopen("input2.txt","r");
	str = (char*)malloc(NMAX * sizeof(int));
	while (!feof(F1))
		fscanf(F1, "%c",&str[i++]);
	fclose(F1);	
//	parser(root, stk, Arr, dim_u, dim_t+1, str);
}
